IXCIO business card — editable files
Page: 102 x 62 mm = 96 x 56 mm trim + 3 mm bleed.

card-front.svg / card-back.svg  — Figma, Illustrator, Affinity, Inkscape, Canva.
  Named groups for every element. Hide/delete the "guides-delete-before-print"
  layer (trim = pink, safe area = yellow) before exporting to PDF.
IXCIO_business_card_editable.pptx — slide 1 front, slide 2 back, exact card size.

Fonts: Cormorant Garamond + Inter (fonts.google.com). Lora included as fallback.
QR: https://ixciodigihealth.com/meet — a redirect on the website, so its
destination can change without reprinting.
